#unction disabletrial:new_world
scoreboard objectives add dt.id dummy
scoreboard objectives add dt.check dummy
scoreboard objectives add dt.displayid dummy
scoreboard objectives add dt.markerid dummy
scoreboard objectives add dt.raycast dummy
scoreboard objectives add dt.max dummy
scoreboard objectives add dt.setdidto dummy
scoreboard objectives add dt.warn dummy
scoreboard objectives add dt.nomessage trigger
scoreboard objectives add dt.time dummy
scoreboard objectives add dt.success dummy
scoreboard objectives add dt.cooldown dummy
scoreboard objectives add dt.adventure dummy