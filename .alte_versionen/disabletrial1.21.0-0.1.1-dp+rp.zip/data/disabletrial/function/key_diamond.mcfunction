#adding damage to the item vie this very large item modifier
item modify entity @s weapon.mainhand disabletrial:damage_predicate10
execute if predicate disabletrial:10broken run playsound minecraft:entity.item.break player @s
execute if predicate disabletrial:10broken run clear @s minecraft:trial_key[damage=10,custom_data={custom_id:"disabletrial:key",dt_key_level:"diamond"}] 1