item modify entity @s weapon.mainhand disabletrial:damage_predicate40
execute if predicate disabletrial:40broken run playsound minecraft:entity.item.break player @s
execute if predicate disabletrial:40broken run clear @s minecraft:trial_key[damage=40,custom_data={custom_id:"disabletrial:key",dt_key_level:"netherite"}] 1