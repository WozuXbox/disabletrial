#adding damage to the item via this very large item modifier
item modify entity @s weapon.mainhand disabletrial:damage_predicate10
#breaking item if needed
execute if predicate disabletrial:10broken run playsound minecraft:entity.item.break player @s
execute if predicate disabletrial:10broken run clear @s minecraft:trial_key[damage=10,custom_data={custom_id:"disabletrial:key",dt_key_level:"diamond"}] 1