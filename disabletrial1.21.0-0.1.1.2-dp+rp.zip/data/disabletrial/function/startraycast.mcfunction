tag @s add dt.cooldown
scoreboard players set @s dt.cooldown 20
execute unless predicate disabletrial:key run return fail
execute unless score dt.adventure dt.adventure matches 1 if entity @s[gamemode=adventure] run return fail
execute if entity @s[tag=dt.nodisable] run return fail
#Here the restriction code part starts

#If you have biomes tagged in #disabletrial:nodisable (located disabletrial/tags/worldgen/biome, uncomment following line
#execute if biome #disabletrial:nodisable run return fail

#If you have a preicate disabletrial:nodisable defined in disabletrial/predicate, uncomment following line.
#execute if predicate disabletrial:nodisable run return fail

#If you want extra conditions, add the code for them here, ideally with execute ... run return fail


tag @s add dt.raycaster
#max length of raycast (may i'll do it via attribute so you geht more reach in creative and stuff in the future idk)
scoreboard players set dt.raycastLimit dt.raycast 45
#call recursive raycastfunction
execute store result score @s dt.success at @s anchored eyes positioned ^ ^ ^.1 run function disabletrial:raycast
tag @s remove dt.raycaster
#If key used, check key -> specific function
execute if score @s dt.success matches 1 unless entity @s[gamemode=creative] if predicate disabletrial:key_level_copper run function disabletrial:key_copper
execute if score @s dt.success matches 1 unless entity @s[gamemode=creative] if predicate disabletrial:key_level_diamond run function disabletrial:key_diamond
execute if score @s dt.success matches 1 unless entity @s[gamemode=creative] if predicate disabletrial:key_level_netherite run function disabletrial:key_netherite